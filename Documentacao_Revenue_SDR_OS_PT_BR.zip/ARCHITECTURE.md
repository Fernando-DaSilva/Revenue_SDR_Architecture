# ARCHITECTURE.md — Decisoes Tecnicas e ADRs (v2.0)

> **COMO o produto e construido.** Decisoes arquiteturais vigentes, com
> contexto, decisao e consequencias. Reflete o estado real do codigo
> (v0.2.0+). Quando uma decisao muda, edita-se este arquivo.

---

## 1. Visao de alto nivel

```
                         HOJE (v0.2.0)                     ALVO (Sprint 9+)
        +-----------------------------------+   +-----------------------------------+
        |  Uma instalacao FastAPI por       |   |  Platform Console (MyraOS)        |
        |  ambiente, multi-tenant logico    |   |   + registry de releases          |
        |  (Organizations isoladas por      |   |   + monitoramento agregado        |
        |  organization_id)                 |   |   + billing                       |
        |                                   |   |        |                          |
        |  app self-contained:              |   |  Client Node (VPS por cliente)    |
        |   - Turso (libSQL) / .db local    |   |   + este app, 1 tenant ou poucos  |
        |   - assets vendored (sem CDN)     |   |   + Update Agent (systemd)        |
        |   - Alembic upgrade no boot       |   |   + pull de updates a cada 6h     |
        +-----------------------------------+   |   + rollback automatico           |
                                                 +-----------------------------------+
```

A transicao e incremental: o multi-tenancy logico de hoje vira o
multi-tenancy fisico de amanha sem reescrita, porque o app ja e
self-contained e o schema ja e isolado por tenant.

## 2. Arquitetura do app (v0.2.0 — vigente)

```
Request
  |
  v
SecurityHeadersMiddleware  (headers de endurecimento + CSP)
  v
TenantResolutionMiddleware (ASGI puro: custom_domain/subdominio -> header
  |                         -> query param (dev) -> default; seta
  |                         request.state.organization + ContextVar)
  v
Router (fino)
  |
  v
Dependency (auth/tenancy)  CurrentOrganization, CurrentUser (cookie|Bearer),
  |                        require_role(...)
  v
Service (*/service.py)     regras de negocio + queries (SEMPRE filtradas
  |                        por organization_id)
  v
Model (SQLModel)           TenantMixin (organization_id obrigatorio) +
                           TimestampMixin (UTC aware, onupdate)
```

### Invariantes (verdades que nao se quebram)

1. **App factory**: `create_app(settings, db_engine)` — sem singletons de
   modulo; tudo vive em `app.state` (settings, db_engine, jinja_env).
2. **Camadas**: rota fina -> service -> model. Query NUNCA na rota.
3. **Erros**: envelope `{"error": {code, message, details}}` via
   `AppError` + handlers registrados na factory.
4. **Validacao de entrada nos schemas pydantic**, nao nos table models
   (SQLModel `table=True` NAO valida). Banco garante integridade via
   constraints (unique, FK, NOT NULL).
5. **Schema so muda via migration Alembic.** `create_all` so em testes.
6. **Templates via `app/web/templating.py::render()`** — injeta tema/branding
   do tenant automaticamente.

## 3. Multi-tenancy — defesa em profundidade

| Camada | Mecanismo |
|---|---|
| Banco | `organization_id` FK NOT NULL em toda tabela de dominio; uniques compostas (ex: `uq_users_org_email`) |
| Middleware | Resolve tenant por request; seta `request.state.organization` + ContextVar `current_organization` |
| JWT | Claim `org` precisa bater com o tenant do request — token nao opera fora do tenant de origem |
| Services | Toda query filtra `organization_id`; acesso por ID retorna **404 generico** cross-tenant (nao vaza existencia) |
| Testes | Suite de isolamento cross-tenant obrigatoria por feature (57+ testes) |

Resolucao de tenant (precedencia): `custom_domain` exato (Host) ou
subdominio -> header `X-Tenant-Slug` -> query param (so dev) ->
`DEFAULT_TENANT_SLUG` (se configurado; vazio em producao = 404).

## 4. Autenticacao

- **Senhas**: Argon2id via pwdlib (recomendacao OWASP).
- **Sessao**: JWT HS256 (PyJWT) com `sub`, `org`, `type=session`, `jti`
  unico (preparado para revogacao futura), expiracao configuravel.
- **Transporte duplo**: cookie HttpOnly `rsdros_session` (precedencia,
  browser) + `Authorization: Bearer` (API). O login JSON entrega os dois.
- Cookie: `secure` em producao, `samesite=lax`, `path=/`.

## 5. Eventos append-only (visao de dados)

Sprint 2 introduz `lead_timeline_events`; Sprint 3 generaliza para uma
tabela central de eventos do dominio. Regras:

- Eventos sao **imutaveis** (append-only) e carregam `payload` JSON.
- Toda mudanca relevante emite evento: `created`, `status_changed`,
  `merged`, `memory_added`, `score_changed`, `cadence_step_advanced`...
- Eventos alimentam: timeline do lead, scoring, analytics e replay.

## 6. Jobs assincronos (Sprint 3+)

- Fila leve (ARQ ou APScheduler) para cadencias, missoes diarias e
  processamento de webhooks.
- Jobs **idempotentes** por construcao (chaves de dedup + checagem de
  estado antes de agir).
- Hoje (S2): processamento e sincrono; a fila entra com a Cadence Engine.

---

## 7. ADRs (Architecture Decision Records)

### ADR-001 — HTMX + Alpine.js + Tailwind (DaisyUI), NÃO React/Vue/Next
- **Contexto**: SPA pesada adiciona complexidade sem ganho para um app server-driven white-label. O uso prévio de "CSS puro" limitava a estética e escalabilidade visual moderna.
- **Decisão**: Jinja2 + HTMX (requisições parciais) + Alpine (microinteratividade). Adoção do **Tailwind CSS + DaisyUI** para design system e componentização semântica, integrado perfeitamente ao ecossistema sem JS extra (Virtual DOM).
- **Consequências**: Frontend dinâmico, server-rendered, com estética altamente profissional. Necessidade de rodar o CLI do Tailwind (com DaisyUI) localmente para gerar o `theme.css` final e integrá-lo via variáveis nativas para o sistema de White Label (ADR-013). Libs HTMX/Alpine permanecem **vendored**.

### ADR-002 — Turso (libSQL) & Embedded Replicas primeiro, NAO Postgres no MVP
- **Contexto**: uma VPS por cliente pede zero-infra e custo zero, mas exige resiliência de backup e performance.
- **Decisao**: Usar **Turso (libSQL)** com suporte a arquivo local `.db` (modo standalone) e opção de *Embedded Replicas* para backup automático em nuvem via dialect `sqlite+libsql://`. SQLModel/SQLAlchemy e Alembic 100% compatíveis (ver ADR-016).
- **Consequencias**: backups automatizados em nuvem sem travar I/O local; leitura ultrarrápida no `.db` local da VPS; custo R$ 0,00 no modo standalone ou no plano Hobby do Turso.

### ADR-003 — Z-API para Zap no MVP (Sprint 4)
- **Contexto**: API oficial (Meta Cloud) tem friccao de aprovacao/custo no
  MVP; Z-API (unofficial) funciona hoje.
- **Decisao**: abstracao `ZapProvider`; implementacao Z-API primeiro;
  migracao para Twilio/Meta e mecanica pela interface.
- **Consequencias**: risco de banimento do numero mitigado pela abstracao
  e por playbooks de aquecimento.

### ADR-004 — VPS dedicada por cliente, NAO SaaS compartilhado
- **Contexto**: LGPD, isolamento absoluto e white-label real (dominio do
  cliente).
- **Decisao**: modelo On-Premise-as-a-Service com Platform Console como
  orquestrador (Sprint 9+).
- **Consequencias**: app precisa ser self-contained (assets vendored,
  SQLite, Alembic no deploy); distribuicao de updates exige Update Agent +
  rollback.

### ADR-005 — SSE, NAO WebSocket
- **Contexto**: real-time do produto e predominantemente servidor->cliente
  (mensagens da IA, transcricao, DHS).
- **Decisao**: SSE (sse-starlette) com broker in-memory, migravel a Redis
  Pub/Sub. WebSocket so se o vendedor digitar pela plataforma (S6+).
- **Consequencias**: simplicidade de proxy/auth; auto-reconnect nativo.

### ADR-006 — Argon2id + PyJWT, NAO passlib/python-jose (v0.2.0)
- **Contexto**: passlib sem release desde 2020 (incompativel bcrypt>=4.1);
  python-jose abandonado com CVEs abertos (CVE-2024-33663/64).
- **Decisao**: pwdlib (Argon2id) para senhas; PyJWT para tokens.
- **Consequencias**: stack de seguranca mantida; hashes Argon2id desde o
  seed; sem legado bcrypt a migrar.

### ADR-007 — App factory + service layer (v0.2.0)
- **Contexto**: v0.1.0 tinha engine/settings em import-time, tornando
  testes frageis (hack de env antes do import) e acoplando tudo.
- **Decisao**: `create_app(settings, db_engine)`; estado em `app.state`;
  regras de negocio em `*/service.py`; rotas finas.
- **Consequencias**: testes constroem apps isoladas com engine em memoria
  injetada; nenhum singleton de modulo.

### ADR-008 — Envelope de erros unico (v0.2.0)
- **Contexto**: respostas de erro inconsistentes (`{"detail": ...}` solto).
- **Decisao**: `AppError` + handlers -> `{"error": {code, message,
  details}}` em JSON para API e pagina HTML minima para rotas web.
- **Consequencias**: contrato de erro estavel para clients; codigos
  testaveis (`tenant_not_found`, `authentication_failed`...).

### ADR-009 — Tenant por middleware ASGI puro + ContextVar (v0.2.0)
- **Contexto**: BaseHTTPMiddleware quebra propagacao de contextvars e
  adiciona overhead; futuros jobs/mixins de ORM precisam do tenant sem
  Request.
- **Decisao**: middleware ASGI puro que seta `request.state.organization`
  e a ContextVar `current_organization`.
- **Consequencias**: ContextVar disponivel para services/jobs; custo de 1
  query por request (cacheavel no futuro).

### ADR-010 — Alembic desde o dia zero (v0.2.0)
- **Contexto**: v0.1.0 criava tabelas via `create_all` (sem versionamento)
  e a pasta alembic/ era vazia.
- **Decisao**: schema so muda via migration; `create_all` apenas em
  testes; `./start` roda `alembic upgrade head` antes de subir.
- **Consequencias**: deploy em VPS = pull + migrate; rollback de schema
  possivel (downgrade testado).

### ADR-011 — Assets frontend vendored, NAO CDN (v0.2.0)
- **Contexto**: CDN quebra o requisito self-contained do modelo VPS
  (ADR-004) e vaza versao/origem.
- **Decisao**: HTMX/Alpine fixados em `app/web/static/js/vendor/`; CSP
  `script-src 'self'` (com `unsafe-eval` enquanto Alpine exigir).
- **Consequencias**: app funciona offline; atualizacao de libs e
  deliberada (download + commit).

### ADR-012 — Validacao nos schemas, NAO nos table models (v0.2.0)
- **Contexto**: SQLModel `table=True` nao executa validacao pydantic —
  `regex=`/`min_length=` em table models sao decorativos (descoberto na
  reescrita).
- **Decisao**: validacao de entrada vive nos schemas de API; banco garante
  integridade via constraints (unique, FK, NOT NULL).
- **Consequencias**: fronteira clara: schemas validam, models persistem,
  banco reforca.

### ADR-013 — Customização de Idiomas por Tela/Usuário e Presets de Cores (v2.1.0)
- **Contexto**: A internacionalização padrão baseada em arquivos é rígida demais para parceiros white-label que precisam adaptar nomes e termos conforme suas marcas (ex: mudar "Leads" para "Contatos" ou "Oportunidades"). Além disso, a customização de cores precisa de presets estéticos predefinidos.
- **Decisão**: Criar a tabela `user_translations` para sobrescrever chaves de tradução por tela e por usuário. Definir 5 presets de cores iniciais (Sakura Bloom, Emerald Garden, Ocean Breeze, Obsidian Night e Amber Warmth) no banco de dados e injetar as variáveis CSS no template base de acordo com a escolha do tenant.
- **Consequências**: Maior flexibilidade no White-label real. Uso de cache em memória para mitigar overhead de query no banco a cada carregamento de página.

### ADR-014 — Logs Estruturados e Observabilidade (JSON, Tracing)
- **Contexto**: A operação em VPS/SaaS e a complexidade de logs isolados tornavam inviável a detecção de problemas, análises de gargalos (ex: latência em queries e respostas do LLM) ou tracing de transações.
- **Decisão**: Implementar logs unificados em JSON Lines (`structlog`), estabelecendo propagação do `request_id`, rastreamento cross-layer (Frontend -> Middleware -> DB/LLM) e um endpoint dedicado (`/api/v1/logs/client`) para ingestão de eventos/erros do Client-side.
- **Consequências**: Tracing robusto das jornadas de requests com contexto enriquecido (tenant_id, user_id). Necessário configurar rate-limiting estrito no ingestor de client-side.

### ADR-015 — Arquivamento de Dados, Tiering de Histórico e Exportação Analítica (PostgreSQL / Supabase)
- **Contexto**: O volume contínuo de conversas de SDR e transcrições sobrecarregaria o banco local (Turso/libSQL) se todo o histórico fosse mantido indefinidamente. Além disso, buscas textuais avançadas e semânticas (RAG) exigem suporte nativo a vetores e FTS.
- **Decisão**: Instituir um modelo de **Storage Tiering (Hot/Cold)**. O Turso/libSQL local mantém apenas os dados de leads ativos e mensagens recentes (Hot Storage). Um pipeline de ETL assíncrono (D-1) replica conversas consolidadas e eventos para o **PostgreSQL / Supabase (Cold Storage / DW)** equipado com `pgvector` e Full-Text Search. Um job de Archiving purga os dados antigos do Turso local após confirmação da sincronia. O acesso na UI permanece unificado via `MessageService` e lazy loading no HTMX.
- **Consequências**: Turso/libSQL se mantém ultraveloz e leve (< 10ms); histórico completo acessível transparente na UI; suporte nativo a RAG e relatórios analíticos pesados sem impactar o atendimento em tempo real.

### ADR-016 — Adoção do Turso (libSQL) com Suporte a Embedded Replicas e Fallback Local
- **Contexto**: O SQLite tradicional isolado trazia desafios para backups em tempo real sem trava de arquivos e observabilidade em escala.
- **Decisão**: Adotar o Turso (libSQL) via `sqlalchemy-libsql`. O sistema grava e lê no arquivo `.db` local da VPS (custo zero, offline-first) e opcionalmente sincroniza em background com o cluster Turso em nuvem via *Embedded Replicas*.
- **Consequências**: Backup contínuo em nuvem sem travar I/O local; suporte a *Database Branching* em CI/CD; 100% de compatibilidade com SQLModel, SQLAlchemy e Alembic.

### ADR-017 — Standalone Zap SDR Micro-App, Grid de Painéis 3 Colunas e Protocolo de Auto-Sync em Background (`02_ZAP_Prototype`)
- **Contexto**: A necessidade de permitir atendimento ao vivo rápido por vendedores e SDRs sem carregar a interface administrativa central motivou a criação do sub-produto standalone **02_ZAP_Prototype**.
- **Decisão**: Implementar a aplicação de atendimento Zap Web em arquitetura de **Standalone Micro-App**: layout grid de 3 colunas com controle independente de painéis (move/minimize/maximize), alternador de modo (`🤖 Copilot Active` vs `👤 SDR Humano`), player de áudio com transcrição Whisper, gráfico de saúde da negociação (**DHS Score** via Chart.js v4), sugestões RAG da base central e protocolo de **Auto-Sync em Background** (`dispatchAutoSyncEvent`) com fila offline em `localStorage`.
- **Consequências**: Experiência ultra-leve para o operador de vendas com garantia de sincronia total de histórico, métricas DHS e feedback RAG com o backend do Core SDR OS.

---

*"Arquitetura e a arte de tomar decisoes faceis de reverter."*


